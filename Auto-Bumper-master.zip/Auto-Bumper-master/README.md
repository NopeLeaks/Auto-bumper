<img src="https://img.shields.io/github/watchers/Rdimo/Instagram-Mass-report?color=%237289DA&label=Watchers" alt="shield.png"></a>
<img src="https://img.shields.io/github/stars/Rdimo/Instagram-Mass-report?color=%237289DA&label=Stars" alt="shield.png"></a>
<a href="https://rdimo.github.io/CheatAway/" target="_blank"> <img src="https://discordapp.com/api/guilds/850313477121507338/widget.png?style=shield" alt="shield.png"></a>

### Auto Bumper was made by
Love ❌
code ✅

Got bored and wanted to try making a self bot in python, 😳
	
|    Step by Step Installation 		|
| ------------------------------------ 	|
| Start by getting your discordtoken・[Tutorial here](https://www.youtube.com/watch?v=YEgFvgg7ZPI&t=1s)	|
| [Download](https://github.com/Rdimo/Auto-Bumper/archive/refs/heads/master.zip) this project as a zip, then extract it or do ```git clone https://github.com/Rdimo/Auto-Bumper```	|
| Run install_requirements.cmd to install the modules 	|
| Open the folder in [visual studio code](https://code.visualstudio.com/Download#) or other editor of your choice and put in your token on line 22							|
| Additionally if you want to you can change the prefix on line 4, by default it's * 	|
| Now run the script by either doing python main.py in the console or just run run.bat 	|
| Now just go the the channel you want to auto bump in and type *bump and it will start bumping! 	|

| 🌟Star this repository if it has helped you!|
|----------------------------------------------|

Created by Rdimo#6969 | https://rdimo.github.io/CheatAway
